# Devpost Submission Content: SafeVision — AI-AR Predictive Safety Navigation

**Title:** SafeVision: AI-AR Powered Predictive Safety Navigation

**Short Pitch:** A lightweight web prototype that fuses in-browser AI detection with AR-style overlays to provide predictive hazard alerts in real-time using only a webcam — designed as a privacy-friendly, deployable safety assistant.

**Problem:** Many accidents occur because pedestrians/cyclists/drivers miss hazards. Low-cost protective tech lacking.

**Solution:** SafeVision detects objects and predicts potential hazards (e.g., approaching vehicles, obstacles) and displays AR-style warnings and guidance.

**What it does:** Real-time detection, AR overlays, simple predictive heuristic for "close" hazards.

**Tech Stack:** TensorFlow.js (COCO-SSD), HTML/CSS/JS, Canvas overlays. (Prototype)

**How we built it:** Frontend-only demo to prove concept — runs the COCO-SSD model in-browser and overlays warnings on a canvas positioned above the video feed.

**Challenges:** Achieving low-latency detection, designing intuitive overlay UX, and defining reliable predictive heuristics.

**Accomplishments:** Working in-browser prototype with live detection and AR-like alerts.

**Future work:** Replace model with hazard-specific detector, integrate sensor fusion & map data, mobile PWA and ARCore/WebXR support, voice alerts.

**GitHub / Live Demo:** (Add your repo or hosted demo link here)

**Video demo link:** (Add YouTube or Vimeo link)

**Team:** (Add your name / team members)
